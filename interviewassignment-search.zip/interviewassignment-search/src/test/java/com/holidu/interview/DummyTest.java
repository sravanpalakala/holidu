package com.holidu.interview;

import org.junit.Assert;
import org.junit.Test;

public class DummyTest {

    @Test
    public void someTest() {
        Assert.assertTrue(true);
    }
}
